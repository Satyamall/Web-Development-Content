var firstName = "Satya";
var lastName = "Mall";
var age = 21;
var Address = "#125";
var City = "Kushinagar";
var State ="Uttar Pradesh";
var Pincode = 274402;

var details = firstName + " " + lastName + " " + "," +
    "\n" + "Age is: " + age + "," +
    "\n" + "Address, " +
    "\n" + Address + "," +
    "\n" + City + "," +
    "\n" + State + "," +
    "\n" + "PINCODE: " + Pincode;

console.log(details)

