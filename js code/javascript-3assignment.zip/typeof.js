

// 1729 - nunber
console.log(typeof 1729)

// "Masai School" - string
console.log(typeof "Masai School")

// false - boolean
console.log(typeof false)

// "" - string
console.log(typeof "")

// undefined - "undefined"
console.log(typeof undefined)



