var indiaScore = 200;
var pakScore = 200;

if(indiaScore > pakScore){
    console.log("India Wins");
}
else if(indiaScore < pakScore){
    console.log("Pakistan Wins");
}
else if(indiaScore === pakScore){
    console.log("Match Tied")
}