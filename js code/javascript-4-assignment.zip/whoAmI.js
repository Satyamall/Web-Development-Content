// * Polygon

var numOfLines = 3;

switch(numOfLines){
    case 3:
        console.log("triangle");
        break;
    case 4:
        console.log("quadrilateral");
        break;
    case 5:
        console.log("pentagon");
        break;
    case 6:
        console.log("hexagon");
        break;
    default:
        break;
}